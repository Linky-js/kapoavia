import { c as defineEventHandler, e as setResponseHeader } from '../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const sitemap_xml_get = defineEventHandler((event) => {
  const siteUrl = "https://\u043A\u0430\u043F\u043E-\u0430\u0432\u0438\u0430.\u0440\u0444";
  const pagesDir = path.resolve(process.cwd(), "app/pages");
  let files = [];
  try {
    files = fs.readdirSync(pagesDir);
  } catch (e) {
    const xml2 = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${siteUrl}/</loc>
  </url>
</urlset>`;
    setResponseHeader(event, "Content-Type", "application/xml");
    return xml2;
  }
  const routes = files.filter((f) => f.endsWith(".vue")).map((f) => f.replace(/\.vue$/, "")).filter((name) => !name.startsWith("_")).map((name) => name === "index" ? "/" : `/${name}`);
  const urls = routes.map((r) => `${siteUrl}${r}`);
  const urlEntries = urls.map((u) => `  <url>
    <loc>${u}</loc>
  </url>`).join("\n");
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries}
</urlset>`;
  setResponseHeader(event, "Content-Type", "application/xml");
  return xml;
});

export { sitemap_xml_get as default };
//# sourceMappingURL=sitemap.xml.get.mjs.map
